package com.demo.service.impl;

import com.demo.service.ArticleService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)     //表示继承了SpringJUnit4ClassRunner类
@ContextConfiguration(locations = {"classpath:spring-mybatis.xml"})
public class ArticleServiceImplTest {
    @Resource
    private ArticleService articleService;

    @Test
    public void addArticle() {
    }

    @Test
    public void updateUser() {
    }

    @Test
    public void delArticle() {
    }

    @Test
    public void importBatchArticles() {
        articleService.importArticles();
    }

    @Test
    public void getArticleById() {

        System.out.printf(articleService.getArticleById("10").toString());
    }
}