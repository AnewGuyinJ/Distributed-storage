package com.demo.service.impl;

import com.demo.dao.entity.ReadEntity;
import com.demo.service.ReadService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.HashMap;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)     //表示继承了SpringJUnit4ClassRunner类
@ContextConfiguration(locations = {"classpath:spring-mybatis.xml"})
public class ReadServiceImplTest {
    @Resource
    private ReadService readService;

    @Test
    public void addRead() {
        ReadEntity readEntity=new ReadEntity();
        readEntity.setTimestamp("1506332307000");
        readEntity.setUid("9546");
        readEntity.setAid("1447");
        readEntity.setReadOrNot("1");
        readEntity.setReadTimeLength("27");
        readEntity.setAgreeOrNot("1");
        readEntity.setCommentOrNot("1");
        readEntity.setShareOrNot("1");
        readEntity.setReadSequence("3");
        readEntity.setCommentDetail("comments to this article: (2486,54540)");
        readService.insertRead(readEntity);
    }

    @Test
    public void updateRead() {
    }

    @Test
    public void delRead() {
    }

    @Test
    public void importReads() {
        readService.importReads();
    }

    @Test
    public void getReadById() {
        HashMap<String,String> ids=new HashMap<String, String>();
        ids.put("uid","1");
        ids.put("aid","55555");
        System.out.println(ids.toString());
        System.out.println(readService.getReadById(ids).toString());

    }

    @Test
    public void getUidsByAid() {
        System.out.println(readService.getUidsByAid("1447"));
    }
}