package com.demo.service.impl;

import com.demo.dao.bj.BJReadDao;
import com.demo.dao.entity.BeReadEntity;
import com.demo.dao.entity.ReadEntity;
import com.demo.dao.hk.HKArticleDao;
import com.demo.dao.hk.HKReadDao;
import com.demo.service.ArticleService;
import com.demo.service.BeService;
import com.demo.service.ReadService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;

import java.util.ArrayList;

import static org.junit.Assert.*;
@RunWith(SpringJUnit4ClassRunner.class)     //表示继承了SpringJUnit4ClassRunner类
@ContextConfiguration(locations = {"classpath:spring-mybatis.xml"})
public class BeServiceImplTest {
    @Resource
    private BeService beService;
    @Resource
    private BJReadDao bjReadDao;
    @Resource
    private HKReadDao hkReadDao;
    @Resource
    private ReadService readService;
    @Test
    public void insertBeRead() {
        String aid="1447";
        ArrayList<ReadEntity> readEntities=readService.selectReadByAid(aid);
        BeReadEntity beReadEntity=new BeReadEntity();
        beReadEntity.setTimestamp("1506332297000");
        beReadEntity.setAid(aid);
        int readNum;
        int commentNum;
        int agreeNum;
        int shareNum;
        readNum=commentNum=agreeNum=shareNum=0;
        ArrayList<String> readlist=new ArrayList<String>();
        ArrayList<String> commentlist=new ArrayList<String>();
        ArrayList<String> agreelist=new ArrayList<String>();
        ArrayList<String> sharelist=new ArrayList<String>();

        for (ReadEntity readEntity:readEntities){
            String uid=readEntity.getUid();
        if(readEntity.getReadOrNot().equals("1")){
            readNum++;
            readlist.add(uid);
        }
        if(readEntity.getCommentOrNot().equals("1")){
            commentNum++;
            commentlist.add(uid);
        }
        if (readEntity.getAgreeOrNot().equals("1")){
            agreelist.add(uid);
            agreeNum++;
        }
        if (readEntity.getShareOrNot().equals("1")){
            sharelist.add(uid);
            shareNum++;
        }
        }
        beReadEntity.setReadNum(String.valueOf(readNum));
        beReadEntity.setReadUidList(readlist);
        beReadEntity.setCommentNum(String.valueOf(commentNum));
        beReadEntity.setCommentUidList(commentlist);
        beReadEntity.setAgreeNum(String.valueOf(agreeNum));
        beReadEntity.setAgreeUidList(agreelist);
        beReadEntity.setShareNum(String.valueOf(shareNum));
        beReadEntity.setShareUidList(sharelist);
        System.out.println(beReadEntity);
        System.out.println(beService.addBe(beReadEntity));
    }
}