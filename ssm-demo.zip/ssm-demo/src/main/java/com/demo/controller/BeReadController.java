package com.demo.controller;

public class BeReadController {
}
