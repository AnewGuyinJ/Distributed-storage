package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;

@Controller
public class ErrorController {
    @RequestMapping(value="error.action")
    public @ResponseBody
    HashMap<String,String> error(HttpServletResponse response, String errormessage)
    {
        HashMap<String,String> map = new HashMap<String,String>();
        map.put("errormessage", errormessage);
        return map;
    }
}
