package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class PageChangeController {
    @RequestMapping(value="pagechange.action")
    public String change(String page)
    {
        return page;
    }

    @RequestMapping(value="pagemanage.action")
    public String change()
    {
        return "home";
    }
}
