package com.demo.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
public class UserController {
    @RequestMapping(value="getUserById.action")
    public @ResponseBody
    String getUserById(HttpServletRequest request, HttpServletResponse response)throws Exception{
        try{

        }catch(Exception e){
            System.out.println("error.action?errormessage=" + e.getMessage());
            request.getRequestDispatcher("error.action?errormessage=" + e.getMessage()).forward(request, response);
        }
        return null;
    }
}
