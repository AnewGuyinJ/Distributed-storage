package com.demo.dao;

import com.demo.dao.entity.ReadEntity;

import java.util.ArrayList;
import java.util.HashMap;

public interface ReadDao {

    Integer insertRead(ReadEntity readEntity);


    Integer importReads(ArrayList<ReadEntity> readEntities);


    Integer updateRead(ReadEntity readEntity);


    ReadEntity selectReadById(HashMap<String, String> ids);


    Integer deleteRead(ReadEntity readEntity);

    ArrayList<String> selectUidsByAid(String aid);

    ArrayList<ReadEntity> selectReadByAid(String aid);

}