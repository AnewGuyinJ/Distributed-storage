package com.demo.dao;

import com.demo.dao.entity.BeReadEntity;
import com.demo.dao.entity.ReadEntity;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
@Repository
public interface BeDao {

    Integer insertBeRead(BeReadEntity beReadEntity);

    Integer selectBeReadByAid(String aid);

    Integer deleteBeRead(BeReadEntity beReadEntity);


}