package com.demo.dao.hk;

import com.demo.dao.UserBaseDao;

public interface HKUserDao extends UserBaseDao {

}