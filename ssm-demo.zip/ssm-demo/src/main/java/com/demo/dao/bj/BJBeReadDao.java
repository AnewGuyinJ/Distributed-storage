package com.demo.dao.bj;


import com.demo.dao.BeReadDao;


public interface BJBeReadDao  extends BeReadDao {

}