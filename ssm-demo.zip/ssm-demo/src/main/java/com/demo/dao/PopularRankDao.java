package com.demo.dao;


public interface PopularRankDao {

}