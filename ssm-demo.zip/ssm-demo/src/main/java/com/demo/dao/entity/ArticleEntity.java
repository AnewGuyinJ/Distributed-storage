package com.demo.dao.entity;

public class ArticleEntity {

    private String timestamp;
    private String aid;
    private String title;
    private String category;
    private String Abstract;
    private String articleTags;
    private String authors;
    private String language;
    private String text;
    private String image;
    private String video;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAbstract() {
        return Abstract;
    }

    public void setAbstract(String anAbstract) {
        Abstract = anAbstract;
    }

    public String getArticleTags() {
        return articleTags;
    }

    public void setArticleTags(String articleTags) {
        this.articleTags = articleTags;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    @Override
    public String toString() {
        return "ArticleEntity{" +
                "timestamp='" + timestamp + '\'' +
                ", aid='" + aid + '\'' +
                ", title='" + title + '\'' +
                ", category='" + category + '\'' +
                ", Abstract='" + Abstract + '\'' +
                ", articleTags='" + articleTags + '\'' +
                ", authors='" + authors + '\'' +
                ", language='" + language + '\'' +
                ", text='" + text + '\'' +
                ", image='" + image + '\'' +
                ", video='" + video + '\'' +
                '}';
    }
}
