package com.demo.dao.hk;

import com.demo.dao.BeDao;


public interface HKBeDao extends BeDao {


}