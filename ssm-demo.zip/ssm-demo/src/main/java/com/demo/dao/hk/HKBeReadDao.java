package com.demo.dao.hk;


import com.demo.dao.BeReadDao;


public interface HKBeReadDao extends BeReadDao {

}