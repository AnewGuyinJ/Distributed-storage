package com.demo.dao.hk;

import com.demo.dao.ArticleBaseDao;


public interface HKArticleDao extends ArticleBaseDao {


}