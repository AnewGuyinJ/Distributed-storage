package com.demo.dao.bj;

import com.demo.dao.BeDao;


public interface BJBeDao extends BeDao {


}