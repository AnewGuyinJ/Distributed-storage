package com.demo.dao.bj;

import com.demo.dao.ReadDao;

public interface BJReadDao extends ReadDao {


}