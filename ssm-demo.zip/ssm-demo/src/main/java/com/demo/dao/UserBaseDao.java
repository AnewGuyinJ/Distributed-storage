package com.demo.dao;
import com.demo.dao.entity.UserEntity;

import java.util.ArrayList;

public interface UserBaseDao{

    Integer insertUser(UserEntity userEntity);

    Integer deleteUser(UserEntity userEntity);


    Integer importUsers(ArrayList<UserEntity> userEntitys);


    Integer updateUser(UserEntity userEntity);


    UserEntity selectUserById(String uid);

    ArrayList<String> selectUserUids();
}