package com.demo.dao;


import com.demo.dao.entity.BeReadEntity;

import java.util.ArrayList;

public interface BeReadDao {
    Integer insertBeRead(BeReadEntity beReadEntity);

    Integer importBeReads(ArrayList<BeReadEntity> beReadEntities);

    Integer updateBeRead(BeReadEntity BeReadEntity);

    BeReadEntity selectBeReadById(String aid);

    Integer deleteBeRead(BeReadEntity beReadEntity);



}