package com.demo.dao;
import com.demo.dao.entity.ArticleEntity;
import com.demo.dao.entity.UserEntity;


import java.util.ArrayList;

public interface ArticleBaseDao {

    Integer insertArticle(ArticleEntity articleEntity);


    Integer deleteArticle(ArticleEntity articleEntity);


    Integer importArticles(ArrayList<ArticleEntity> aticleEntitys);


    Integer updateArticle(ArticleEntity articleEntity);



    ArticleEntity selectArticleById(String aid);

}