package com.demo.dao.bj;

import com.demo.dao.ArticleBaseDao;
;

public interface BJArticleDao extends ArticleBaseDao {

}