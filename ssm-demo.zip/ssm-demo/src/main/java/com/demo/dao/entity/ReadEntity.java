package com.demo.dao.entity;

public class ReadEntity {
    private String timestamp;
    private String uid;
    private String aid;
    private String readOrNot;
    private String readTimeLength;
    private String readSequence;
    private String agreeOrNot;
    private String commentOrNot;
    private String shareOrNot;
    private String commentDetail;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getReadOrNot() {
        return readOrNot;
    }

    public void setReadOrNot(String readOrNot) {
        this.readOrNot = readOrNot;
    }

    public String getReadTimeLength() {
        return readTimeLength;
    }

    public void setReadTimeLength(String readTimeLength) {
        this.readTimeLength = readTimeLength;
    }

    public String getReadSequence() {
        return readSequence;
    }

    public void setReadSequence(String readSequence) {
        this.readSequence = readSequence;
    }

    public String getAgreeOrNot() {
        return agreeOrNot;
    }

    public void setAgreeOrNot(String agreeOrNot) {
        this.agreeOrNot = agreeOrNot;
    }

    public String getCommentOrNot() {
        return commentOrNot;
    }

    public void setCommentOrNot(String commentOrNot) {
        this.commentOrNot = commentOrNot;
    }

    public String getShareOrNot() {
        return shareOrNot;
    }

    public void setShareOrNot(String shareOrNot) {
        this.shareOrNot = shareOrNot;
    }

    public String getCommentDetail() {
        return commentDetail;
    }

    public void setCommentDetail(String commentDetail) {
        this.commentDetail = commentDetail;
    }

    @Override
    public String toString() {
        return "ReadEntity{" +
                "timestamp='" + timestamp + '\'' +
                ", uid='" + uid + '\'' +
                ", aid='" + aid + '\'' +
                ", readOrNot='" + readOrNot + '\'' +
                ", readTimeLength='" + readTimeLength + '\'' +
                ", readSequence='" + readSequence + '\'' +
                ", agreeOrNot='" + agreeOrNot + '\'' +
                ", commentOrNot='" + commentOrNot + '\'' +
                ", shareOrNot='" + shareOrNot + '\'' +
                ", commentDetail='" + commentDetail + '\'' +
                '}';
    }
}
