package com.demo.dao.entity;

import java.util.ArrayList;


public class BeReadEntity {
    private String timestamp;
    private String aid;
    private String readNum;
    private String readUidList;
    private String commentNum;
    private String commentUidList;
    private String agreeNum;
    private String agreeUidList;
    private String shareNum;
    private String shareUidList;


    public String getReadUidList() {
        return readUidList;
    }

    public void setReadUidList(ArrayList<String> readUidList) {
        String uids="";
        for(String uid : readUidList){
            uids+=uid+",";
        }
        this.readUidList = uids;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getReadNum() {
        return readNum;
    }

    public void setReadNum(String readNum) {
        this.readNum = readNum;
    }

    public String getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(String commentNum) {
        this.commentNum = commentNum;
    }

    public String getCommentUidList() {
        return commentUidList;
    }

    public void setCommentUidList(ArrayList<String> commentUidList) {
        String uids="";
        for(String uid : commentUidList){
            uids+=uid+",";
        }
        this.commentUidList = uids;
    }

    public String getAgreeNum() {
        return agreeNum;
    }

    public void setAgreeNum(String agreeNum) {
        this.agreeNum = agreeNum;
    }

    public String getAgreeUidList() {
        return agreeUidList;
    }

    public void setAgreeUidList(ArrayList<String> agreeUidList) {
        String uids="";
        for(String uid : agreeUidList){
            uids+=uid+",";
        }
        this.agreeUidList = uids;
    }

    public String getShareNum() {
        return shareNum;
    }

    public void setShareNum(String shareNum) {
        this.shareNum = shareNum;
    }

    public String getShareUidList() {
        return shareUidList;
    }

    public void setShareUidList(ArrayList<String> shareUidList) {
        String uids="";
        for(String uid : shareUidList){
            uids+=uid+",";
        }
        this.shareUidList = uids;
    }


    @Override
    public String toString() {
        return "BeReadEntity{" +
                "timestamp='" + timestamp + '\'' +
                ", aid='" + aid + '\'' +
                ", readNum='" + readNum + '\'' +
                ", readUidList='" + readUidList + '\'' +
                ", commentNum='" + commentNum + '\'' +
                ", commentUidList='" + commentUidList + '\'' +
                ", agreeNum='" + agreeNum + '\'' +
                ", agreeUidList='" + agreeUidList + '\'' +
                ", shareNum='" + shareNum + '\'' +
                ", shareUidList='" + shareUidList + '\'' +
                '}';
    }
}
