package com.demo.dao.entity;

import java.util.ArrayList;

public class BeReadEntity {
    private String timestamp;
    private String aid;
    private String readNum;
    private ArrayList<String> readUidList;
    private String commentNum;
    private ArrayList<String> commentUidList;
    private String agreeNum;
    private ArrayList<String> agreeUidList;
    private String shareNum;
    private ArrayList<String>  shareUidList;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getReadNum() {
        return readNum;
    }

    public void setReadNum(String readNum) {
        this.readNum = readNum;
    }

    public ArrayList<String> getReadUidList() {
        return readUidList;
    }

    public void setReadUidList(ArrayList<String> readUidList) {
        this.readUidList = readUidList;
    }

    public String getCommentNum() {
        return commentNum;
    }

    public void setCommentNum(String commentNum) {
        this.commentNum = commentNum;
    }

    public ArrayList<String> getCommentUidList() {
        return commentUidList;
    }

    public void setCommentUidList(ArrayList<String> commentUidList) {
        this.commentUidList = commentUidList;
    }

    public String getAgreeNum() {
        return agreeNum;
    }

    public void setAgreeNum(String agreeNum) {
        this.agreeNum = agreeNum;
    }

    public ArrayList<String> getAgreeUidList() {
        return agreeUidList;
    }

    public void setAgreeUidList(ArrayList<String> agreeUidList) {
        this.agreeUidList = agreeUidList;
    }

    public String getShareNum() {
        return shareNum;
    }

    public void setShareNum(String shareNum) {
        this.shareNum = shareNum;
    }

    public ArrayList<String> getShareUidList() {
        return shareUidList;
    }

    public void setShareUidList(ArrayList<String> shareUidList) {
        this.shareUidList = shareUidList;
    }

    @Override
    public String toString() {
        return "BeReadEntity{" +
                "timestamp='" + timestamp + '\'' +
                ", aid='" + aid + '\'' +
                ", readNum='" + readNum + '\'' +
                ", readUidList=" + readUidList +
                ", commentNum='" + commentNum + '\'' +
                ", commentUidList=" + commentUidList +
                ", agreeNum='" + agreeNum + '\'' +
                ", agreeUidList=" + agreeUidList +
                ", shareNum='" + shareNum + '\'' +
                ", shareUidList=" + shareUidList +
                '}';
    }
}
