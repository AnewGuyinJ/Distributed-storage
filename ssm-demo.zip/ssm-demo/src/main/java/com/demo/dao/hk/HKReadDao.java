package com.demo.dao.hk;

import com.demo.dao.ReadDao;


public interface HKReadDao extends ReadDao {
}