package com.demo.dao.entity;

public class UserEntity {

    private String timestamp;
    private String name;
    private String uid;
    private String gender;
    private String email;
    private String phone;
    private String dept;
    private String grade;
    private String language;
    private String region;
    private String role;
    private String preferTags;
    private String obtainedCredits;

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getLanuage() {
        return language;
    }

    public void setLanuage(String language) {
        this.language = language;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPreferTags() {
        return preferTags;
    }

    public void setPreferTags(String preferTags) {
        this.preferTags = preferTags;
    }

    public String getObtainedCredits() {
        return obtainedCredits;
    }

    public void setObtainedCredits(String obtainedCredits) {
        this.obtainedCredits = obtainedCredits;
    }

    @Override
    public String toString() {
        return "UserEntity{" +
                "timestamp='" + timestamp + '\'' +
                ", name='" + name + '\'' +
                ", uid='" + uid + '\'' +
                ", gender='" + gender + '\'' +
                ", email='" + email + '\'' +
                ", phone='" + phone + '\'' +
                ", dept='" + dept + '\'' +
                ", grade='" + grade + '\'' +
                ", lanuage='" + language + '\'' +
                ", region='" + region + '\'' +
                ", role='" + role + '\'' +
                ", preferTags='" + preferTags + '\'' +
                ", obtainedCredits='" + obtainedCredits + '\'' +
                '}';
    }
}
