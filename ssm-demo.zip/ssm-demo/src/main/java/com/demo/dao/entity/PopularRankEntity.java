package com.demo.dao.entity;

import java.util.ArrayList;

public class PopularRankEntity {
    private String timestamp;
    private String temporalGranularity;
    private ArrayList<String> articleAidList;


    public String getTimestamp() {

        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getTemporalGranularity() {
        return temporalGranularity;
    }

    public void setTemporalGranularity(String temporalGranularity) {
        this.temporalGranularity = temporalGranularity;
    }

    public ArrayList<String> getArticleAidList() {
        return articleAidList;
    }

    public void setArticleAidList(ArrayList<String> articleAidList) {
        this.articleAidList = articleAidList;
    }


    @Override
    public String toString() {
        return "PopularRankEntity{" +
                "timestamp='" + timestamp + '\'' +
                ", temporalGranularity='" + temporalGranularity + '\'' +
                ", articleAidList=" + articleAidList +
                '}';
    }
}
