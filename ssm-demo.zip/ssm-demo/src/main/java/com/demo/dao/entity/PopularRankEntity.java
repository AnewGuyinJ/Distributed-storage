package com.demo.dao.entity;

import java.util.ArrayList;

public class PopularRankEntity {
    private String timestamp;
    private String temporalGranularity;
    private String articleAidList;


    public String getTimestamp() {

        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getTemporalGranularity() {
        return temporalGranularity;
    }

    public void setTemporalGranularity(String temporalGranularity) {
        this.temporalGranularity = temporalGranularity;
    }


    public String getArticleAidList() {
        return articleAidList;
    }

    public void setArticleAidList(ArrayList<String> articleAidList) {
        String aids="";
        for(String aid : articleAidList){
            aids+=aid+",";
        }
        this.articleAidList = aids;
    }
}
