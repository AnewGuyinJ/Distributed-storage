package com.demo.dao.bj;
import com.demo.dao.UserBaseDao;

public interface BJUserDao extends UserBaseDao {

}