package com.demo.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.demo.dao.ReadDao;
import com.demo.dao.bj.BJReadDao;
import com.demo.dao.bj.BJUserDao;
import com.demo.dao.entity.ReadEntity;
import com.demo.dao.hk.HKReadDao;
import com.demo.dao.hk.HKUserDao;
import com.demo.service.ReadService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;


@Service
public class ReadServiceImpl implements ReadService {

    @Resource
    private BJReadDao bjReadDao;
    @Resource
    private HKReadDao hkReadDao;
    @Resource
    private BJUserDao bjUserDao;
    @Resource
    private HKUserDao hkUserDao;


    private ReadDao selectDao(boolean para){
        if(para){
            return bjReadDao;
        }
        else {
            return hkReadDao;
        }

    }


    private boolean dichotomy(String[] para,String value){
        int len=para.length;
        int low,high;
        low=0;
        high=len-1;
        int mid;

        while(low<=high)
        {
            mid = (low+high)/2;
            if(para[mid].equals(value))
                return true;
            if(para[mid].compareTo(value)>0)
                high = mid-1;
            if(para[mid].compareTo(value)<0)
                low = mid+1;
        }
        return false;
    }


    @Override
    public Integer insertRead(ReadEntity readEntity) {
        boolean para =  bjUserDao.selectUserById(readEntity.getUid())==null;
        return selectDao(para).insertRead(readEntity);
    }

    @Override
    public Integer updateRead(ReadEntity readEntity) {
        boolean para = bjUserDao.selectUserById(readEntity.getUid())==null;

        return selectDao(para).updateRead(readEntity);
    }

    @Override
    public Integer delRead(ReadEntity readEntity) {
        boolean para = bjUserDao.selectUserById(readEntity.getUid())==null;
        return selectDao(para).deleteRead(readEntity);
    }

    @Override
    public Integer importReads() {

        try {
            String fileName = "/usr/read.dat";
            InputStream is = new FileInputStream(fileName);
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(is));
            String str = null;
            ArrayList<ReadEntity> bjRead = new ArrayList<ReadEntity>();
            ArrayList<ReadEntity> hkRead = new ArrayList<ReadEntity>();
            ArrayList<String> uidInUser = hkUserDao.selectUserUids();
            String[] hkuids = uidInUser.toArray(new String[uidInUser.size()]);
            int line = 1;

            while (true) {
                str = reader.readLine();
                if (str != null) {
                    //System.out.println(str);
                    JSONObject jsonObject = JSON.parseObject(str);
                    String uid = jsonObject.getString("uid");
                    ReadEntity read = new ReadEntity();
                    read.setCommentDetail(jsonObject.getString("commentDetail"));
                    read.setReadSequence(jsonObject.getString("readSequence"));
                    read.setShareOrNot(jsonObject.getString("shareOrNot"));
                    read.setCommentOrNot(jsonObject.getString("commentOrNot"));
                    read.setAgreeOrNot(jsonObject.getString("agreeOrNot"));
                    read.setReadTimeLength(jsonObject.getString("readTimeLength"));
                    read.setReadOrNot(jsonObject.getString("readOrNot"));
                    read.setAid(jsonObject.getString("aid"));
                    read.setUid(jsonObject.getString("uid"));
                    read.setTimestamp(jsonObject.getString("timestamp"));
                    if (dichotomy(hkuids, uid)) {
                        bjRead.add(read);
                    } else {
                        hkRead.add(read);
                    }
                    line++;

                } else
                    break;
            }

            is.close();
            return bjReadDao.importReads(bjRead) & hkReadDao.importReads(hkRead);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }



    @Override
    public ReadEntity getReadById(HashMap<String, String> ids) {
        boolean para=bjUserDao.selectUserById(ids.get("uid"))==null;
        return selectDao(para).selectReadById(ids);
    }

    @Override
    public ArrayList<String> getUidsByAid(String aid) {
        ArrayList<String> uids=new ArrayList<String>();
        uids.addAll(bjReadDao.selectUidsByAid(aid));
        uids.addAll(hkReadDao.selectUidsByAid(aid));
        return uids;
    }

    @Override
    public ArrayList<ReadEntity> selectReadByAid(String aid) {
        ArrayList<ReadEntity> datas=new ArrayList<ReadEntity>();
        datas.addAll(bjReadDao.selectReadByAid(aid));
        datas.addAll(hkReadDao.selectReadByAid(aid));
        return datas;
    }


}
