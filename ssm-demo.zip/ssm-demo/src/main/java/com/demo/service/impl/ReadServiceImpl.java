package com.demo.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.demo.dao.ReadDao;
import com.demo.dao.bj.BJReadDao;
import com.demo.dao.bj.BJUserDao;
import com.demo.dao.entity.ReadEntity;
import com.demo.dao.hk.HKReadDao;
import com.demo.service.ReadService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;


@Service
public class ReadServiceImpl implements ReadService {

    @Resource
    private BJReadDao bjReadDao;
    @Resource
    private HKReadDao hkReadDao;
    @Resource
    private BJUserDao bjUserDao;


    private ReadDao selectDao(boolean para){
        if(para){
            return bjReadDao;
        }
        else {
            return hkReadDao;
        }

    }


    private boolean dichotomy(String[] para,String value){
        int len=para.length;
        int low,high;
        low=0;
        high=len-1;
        int mid;

        while(low<=high)
        {
            mid = (low+high)/2;
            if(para[mid].equals(value))
                return true;
            if(para[mid].compareTo(value)>0)
                high = mid-1;
            if(para[mid].compareTo(value)<0)
                low = mid+1;
        }
        return false;
    }


    @Override
    public Integer insertRead(ReadEntity readEntity) {
        boolean para =  bjUserDao.selectUserById(readEntity.getUid())==null;
        return selectDao(para).insertRead(readEntity);
    }

    @Override
    public Integer updateRead(ReadEntity readEntity) {
        boolean para = bjUserDao.selectUserById(readEntity.getUid())==null;

        return selectDao(para).updateRead(readEntity);
    }

    @Override
    public Integer delRead(ReadEntity readEntity) {
        boolean para = bjUserDao.selectUserById(readEntity.getUid())==null;
        return selectDao(para).deleteRead(readEntity);
    }

    @Override
    public Integer importReads() {
        String fileName="/usr/read.dat";
        File file = new File(fileName);
        BufferedReader reader = null;
        ArrayList<ReadEntity> bjRead=new ArrayList<ReadEntity>();
        ArrayList<ReadEntity> hkRead=new ArrayList<ReadEntity>();
        ArrayList<String> uidInUser=bjUserDao.selectUserUids();
        String[] bjuids=uidInUser.toArray(new String[uidInUser.size()]);
        try {

            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            while ((tempString = reader.readLine()) != null) {
                JSONObject jsonObject= JSON.parseObject(tempString);
                String uid = jsonObject.getString("uid");
                    ReadEntity read=new ReadEntity();
                    read.setCommentDetail(jsonObject.getString("commentDetail"));
                    read.setReadSequence(jsonObject.getString("readSequence"));
                    read.setShareOrNot(jsonObject.getString("shareOrNot"));
                    read.setCommentOrNot(jsonObject.getString("commentOrNot"));
                    read.setAgreeOrNot(jsonObject.getString("agreeOrNot"));
                    read.setReadTimeLength(jsonObject.getString("readTimeLength"));
                    read.setReadOrNot(jsonObject.getString("readOrNot"));
                    read.setAid(jsonObject.getString("aid"));
                    read.setUid(jsonObject.getString("uid"));
                    read.setTimestamp(jsonObject.getString("timestamp"));
                if(dichotomy(bjuids,uid)){
                    bjRead.add(read);
                }else {
                    hkRead.add(read);
                }
                line++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }

        return bjReadDao.importReads(bjRead)&hkReadDao.importReads(hkRead);
    }

    @Override
    public ReadEntity getReadById(HashMap<String, String> ids) {
        boolean para=bjUserDao.selectUserById(ids.get("uid"))==null;
        return selectDao(para).selectReadById(ids);
    }

    @Override
    public ArrayList<String> getUidsByAid() {

        return null;
    }


}
