package com.demo.service;




import com.demo.dao.entity.BeReadEntity;

import java.util.ArrayList;
import java.util.HashMap;


public interface BeReadService {

    Integer addBeRead(BeReadEntity beReadEntity);

    Integer updateBeRead(BeReadEntity beReadEntity);

    Integer delBeRead(BeReadEntity beReadEntity);

    Integer importBeReads();

    BeReadEntity getBeReadById(String aid);


}