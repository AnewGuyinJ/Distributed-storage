package com.demo.service;


import com.demo.dao.entity.ArticleEntity;
import com.demo.dao.entity.ReadEntity;

import java.util.ArrayList;
import java.util.HashMap;


public interface ReadService {

    Integer insertRead(ReadEntity readEntity);

    Integer updateRead(ReadEntity readEntity);

    Integer delRead(ReadEntity readEntity);

    Integer importReads();

    ReadEntity getReadById(HashMap<String,String> ids);

    ArrayList<String> getUidsByAid(String aid);

    ArrayList<ReadEntity> selectReadByAid(String aid);
}