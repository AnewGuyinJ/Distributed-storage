package com.demo.service;


import com.demo.dao.entity.ArticleEntity;


public interface ArticleService {

    Integer addArticle(ArticleEntity article);


    Integer updateArticle(ArticleEntity article);

    Integer delArticle(ArticleEntity articleEntity);

    Integer importArticles();


    ArticleEntity getArticleById(String aid);
}