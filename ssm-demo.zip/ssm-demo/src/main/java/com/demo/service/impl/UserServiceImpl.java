package com.demo.service.impl;



import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.demo.dao.UserBaseDao;
import com.demo.dao.bj.BJUserDao;
import com.demo.dao.entity.UserEntity;
import com.demo.dao.hk.HKUserDao;
import com.demo.service.UserService;
import org.springframework.stereotype.Service;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.annotation.Resource;
import java.util.ArrayList;

@Service
public class UserServiceImpl implements UserService {
    @Resource
    private BJUserDao BJuserDao;

    @Resource
    private HKUserDao HKuserDao;


    private UserBaseDao selectDao(boolean para){
        if(para){
            return BJuserDao;
        }
        else {
            return HKuserDao;
        }

    }

    public Integer createUser(UserEntity userEntity) {

        boolean para=userEntity.getRegion().equals("Beijing");
        return selectDao(para).insertUser(userEntity);
    }



    public Integer updateUser(UserEntity userEntity) {

        Boolean para=userEntity.getRegion().equals("Beijing");
        return selectDao(para).updateUser(userEntity);
    }



    public Integer deleteUser(UserEntity userEntity) {
        Boolean para=userEntity.getRegion().equals("Beijing");
        return selectDao(para).deleteUser(userEntity);
    }


    public Integer importBatchUsers() {
        String fileName="/usr/user.dat";
        File file = new File(fileName);
        BufferedReader reader = null;
        ArrayList<UserEntity> userBJs=new ArrayList<UserEntity>();
        ArrayList<UserEntity> userHKs=new ArrayList<UserEntity>();

        try {
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            while ((tempString = reader.readLine()) != null) {
                JSONObject jsonObject= JSON.parseObject(tempString);
                UserEntity user=new UserEntity();
                user.setUid(jsonObject.getString("uid"));
                user.setTimestamp(jsonObject.getString("timestamp"));
                user.setPreferTags(jsonObject.getString("preferTags"));
                user.setPhone(jsonObject.getString("phone"));
                user.setObtainedCredits(jsonObject.getString("obtainedCredits"));
                user.setLanuage(jsonObject.getString("language"));
                user.setEmail(jsonObject.getString("email"));
                user.setDept(jsonObject.getString("dept"));
                user.setGender(jsonObject.getString("gender"));
                user.setGrade(jsonObject.getString("grade"));
                user.setName(jsonObject.getString("name"));
                user.setRegion(jsonObject.getString("region"));
                user.setRole(jsonObject.getString("role"));

                if(user.getRegion().equals("Beijing")){
                    userBJs.add(user);
                }else {
                    userHKs.add(user);
                }

                line++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }

        return BJuserDao.importUsers(userBJs)&HKuserDao.importUsers(userHKs);


    }


    public UserEntity getUserById(String uid) {
        UserEntity user=BJuserDao.selectUserById(uid);
        if(user==null){
            return HKuserDao.selectUserById(uid);
        }
        return user;
    }

    @Override
    public ArrayList<String> selectUserUids() {
        return BJuserDao.selectUserUids();
    }


}