package com.demo.service;

import com.demo.dao.entity.UserEntity;

import java.util.ArrayList;

/**
 * 用户服务类
 *
 * @author Wwwwei
 */
public interface UserService {

    Integer createUser(UserEntity userEntity);


    Integer updateUser(UserEntity userEntity);


    Integer deleteUser(UserEntity userEntity);


    Integer importBatchUsers();


    UserEntity getUserById(String uid);

    ArrayList<String> selectUserUids();

}