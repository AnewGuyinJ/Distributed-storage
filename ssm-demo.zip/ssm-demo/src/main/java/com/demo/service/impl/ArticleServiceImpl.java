package com.demo.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.demo.dao.ArticleBaseDao;

import com.demo.dao.bj.BJArticleDao;
import com.demo.dao.entity.ArticleEntity;
import com.demo.dao.hk.HKArticleDao;
import com.demo.service.ArticleService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

@Service
public class ArticleServiceImpl implements ArticleService {
    @Resource
    private BJArticleDao BJarticleDao;
    @Resource
    private HKArticleDao HKarticleDao;

    private ArticleBaseDao selectDao(boolean para){
        if(para){
            return BJarticleDao;
        }
        else {
            return HKarticleDao;
        }

    }


    public Integer addArticle(ArticleEntity article) {
        boolean para=article.getCategory().equals("science");
        if(para){
            return BJarticleDao.insertArticle(article)&HKarticleDao.insertArticle(article);
        }
        return HKarticleDao.insertArticle(article);
    }


    public Integer updateArticle(ArticleEntity article) {
        boolean para=article.getCategory().equals("technology");
        if(para){
            return HKarticleDao.updateArticle(article);
        }
        return HKarticleDao.updateArticle(article)&BJarticleDao.updateArticle(article);
    }




    public Integer delArticle(ArticleEntity articleEntity) {
        boolean para=articleEntity.getCategory().equals("technology");
        if (para){
            return HKarticleDao.deleteArticle(articleEntity);
        }
        return HKarticleDao.deleteArticle(articleEntity)&BJarticleDao.deleteArticle(articleEntity);
    }


    public Integer importArticles() {
        String fileName="/usr/article.dat";
        File file = new File(fileName);
        BufferedReader reader = null;
        ArrayList<ArticleEntity> BJArticles=new ArrayList<ArticleEntity>();
        ArrayList<ArticleEntity> HKArticles=new ArrayList<ArticleEntity>();

        try {
            //System.out.println("以行为单位读取文件内容，一次读一整行：");
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;

            while ((tempString = reader.readLine()) != null) {
                JSONObject jsonObject= JSON.parseObject(tempString);

                ArticleEntity article=new ArticleEntity();
                article.setAbstract(jsonObject.getString("abstract"));
                article.setAid(jsonObject.getString("aid"));
                article.setArticleTags(jsonObject.getString("articleTags"));
                article.setAuthors(jsonObject.getString("authors"));
                article.setCategory(jsonObject.getString("category"));
                article.setImage(jsonObject.getString("image"));
                article.setLanguage(jsonObject.getString(""));
                article.setText(jsonObject.getString("text"));
                article.setTimestamp(jsonObject.getString("timestamp"));
                article.setTitle(jsonObject.getString("title"));
                article.setVideo(jsonObject.getString("video"));
                HKArticles.add(article);
                if(article.getCategory().equals("science"))
                    BJArticles.add(article);

                line++;
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }


        return BJarticleDao.importArticles(BJArticles)&HKarticleDao.importArticles(HKArticles);
    }


    public ArticleEntity getArticleById(String aid) {
        ArticleEntity articleEntity=HKarticleDao.selectArticleById(aid);
        if(articleEntity==null){
            return BJarticleDao.selectArticleById(aid);
        }
        return articleEntity;

    }
}
