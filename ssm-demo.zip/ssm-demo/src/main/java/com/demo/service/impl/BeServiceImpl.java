package com.demo.service.impl;

import com.demo.dao.bj.BJBeDao;
import com.demo.dao.entity.BeReadEntity;

import com.demo.dao.hk.HKArticleDao;
import com.demo.dao.hk.HKBeDao;
import com.demo.service.BeService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service
public class BeServiceImpl implements BeService {
    @Resource
    private BJBeDao bjBeDao;
    @Resource
    private HKBeDao hkBeDao;
    @Resource
    private HKArticleDao hkArticleDao;



    @Override
    public Integer addBe(BeReadEntity beReadEntity) {
        String aid=beReadEntity.getAid();
        String category=hkArticleDao.selectArticleById(aid).getCategory();
        boolean para=category.equals("science");
        if (para){
           return bjBeDao.insertBeRead(beReadEntity)&hkBeDao.insertBeRead(beReadEntity);
        }
        return hkBeDao.insertBeRead(beReadEntity);

    }



    @Override
    public Integer delBe(BeReadEntity beReadEntity) {
        String aid=beReadEntity.getAid();
        String category=hkArticleDao.selectArticleById(aid).getCategory();
        boolean para=category.equals("science");
        if (para){
            return bjBeDao.deleteBeRead(beReadEntity)&hkBeDao.deleteBeRead(beReadEntity);
        }
        return hkBeDao.deleteBeRead(beReadEntity);

    }

    @Override
    public Integer selectBeByAid(String aid) {

        return hkBeDao.selectBeReadByAid(aid);

    }
}
