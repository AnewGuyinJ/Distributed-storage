package com.demo.service.impl;


import com.demo.dao.bj.BJBeReadDao;
import com.demo.dao.bj.BJReadDao;
import com.demo.dao.entity.BeReadEntity;
import com.demo.dao.hk.HKArticleDao;
import com.demo.dao.hk.HKBeReadDao;
import com.demo.dao.hk.HKReadDao;
import com.demo.service.BeReadService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;


@Service
public class BeReadServiceImpl implements BeReadService {
    @Resource
    private BJBeReadDao bjBeReadDao;
    @Resource
    private HKBeReadDao hkBeReadDao;
    @Resource
    private HKArticleDao hkArticleDao;
    @Resource
    private BJReadDao bjReadDao;
    @Resource
    private HKReadDao hkReadDao;




    @Override
    public Integer addBeRead(BeReadEntity beReadEntity) {
        int readNum,commentNum,agreeNum,shareNum;
        readNum=commentNum=agreeNum=shareNum=0;
        ArrayList<String> reads=new ArrayList<String>();
        ArrayList<String> comments=new ArrayList<String>();
        ArrayList<String> agrees=new ArrayList<String>();
        ArrayList<String> shares=new ArrayList<String>();

        String aid=beReadEntity.getAid();
        if(hkArticleDao.selectArticleById(aid).equals("science")){
            return bjBeReadDao.insertBeRead(beReadEntity)&hkBeReadDao.insertBeRead(beReadEntity);
        }else {
            return hkBeReadDao.insertBeRead(beReadEntity);
        }

    }

    @Override
    public Integer updateBeRead(BeReadEntity beReadEntity) {
        String aid=beReadEntity.getAid();
        if(hkArticleDao.selectArticleById(aid).equals("science")){
            return bjBeReadDao.updateBeRead(beReadEntity)&hkBeReadDao.updateBeRead(beReadEntity);
        }else {
            return hkBeReadDao.updateBeRead(beReadEntity);
        }

    }

    @Override
    public Integer delBeRead(BeReadEntity beReadEntity) {
        String aid=beReadEntity.getAid();
        if(hkArticleDao.selectArticleById(aid).equals("science")){
            return bjBeReadDao.deleteBeRead(beReadEntity)&hkBeReadDao.deleteBeRead(beReadEntity);
        }else {
            return hkBeReadDao.deleteBeRead(beReadEntity);
        }

    }

    @Override
    public Integer importBeReads() {

        return null;
    }

    @Override
    public BeReadEntity getBeReadById(String aid) {

        return hkBeReadDao.selectBeReadById(aid);
    }

    @Override
    public ArrayList<String> selectUidsByAid() {
        ArrayList<String> bjuids = new ArrayList<String>();
        ArrayList<String> hkuids = new ArrayList<String>();
        ArrayList<String> totaluids = new ArrayList<String>();
        bjuids=bjReadDao.
        return null;
    }
}
