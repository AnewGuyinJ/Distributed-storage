package com.demo.service;


import com.demo.dao.entity.BeReadEntity;
import com.demo.dao.entity.ReadEntity;

import java.util.ArrayList;
import java.util.HashMap;


public interface BeService {

    Integer addBe(BeReadEntity beReadEntity);

    Integer delBe(BeReadEntity beReadEntity);

    Integer selectBeByAid(String aid);
 
}